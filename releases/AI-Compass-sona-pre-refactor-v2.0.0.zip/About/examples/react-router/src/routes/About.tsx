/* examples/react-router/src/routes/About.tsx */
import AboutAICompass from "@/src/components/AboutAICompass";

export default function About() {
  return <AboutAICompass />;
}
